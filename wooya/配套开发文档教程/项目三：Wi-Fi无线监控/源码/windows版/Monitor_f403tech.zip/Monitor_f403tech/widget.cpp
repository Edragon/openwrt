//test v8.0
#include "widget.h"
#include "ui_widget.h"

using namespace std;
using namespace cv;

CvVideoWriter* videowr;
bool record;
uchar* qImageBuffer;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    client=new QTcpSocket;
    qImageBuffer=(uchar *)(malloc(320 * 256 *4 *sizeof(uchar)));

    ui->Image->setStyleSheet("border-width: 1px;border-style: solid;border-color: rgb(0, 0, 110);");
    ui->statuslabel->setStyleSheet("border-width: 1px;border-style: solid;border-color: rgb(0, 0, 110);");

    connect(client,SIGNAL(connected()),this,SLOT(sendrequest()));
    connect(client,SIGNAL(readyRead()),this,SLOT(read()));
    connect(client,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(socketerror()));
}

Widget::~Widget()
{
    delete ui;
    delete client;
    free(qImageBuffer);
}

void Widget::on_connect_clicked()
{
    ui->statuslabel->setText(tr("connecting..."));
    client->connectToHost(ui->lineEdit->text(),ui->port->text().toInt());
}

void Widget::on_stop_clicked()
{
    client->abort();
    block1.clear();
    ui->statuslabel->setText(tr("stoped"));
}

void Widget::on_record_clicked()
{
    CvSize size;
    size.width=320;
    size.height=240;
    QTime time;
    time=time.currentTime();//��õ�ǰʱ�䣬��:08:37:34
    QString Tstr=time.toString()+".avi";//ת����QString���ͣ���08:37:34.avi
    Tstr=Tstr.replace(QChar(':'),QLatin1String("-"));//��:����-����Ϊwindows���ļ������ܺ�:
    const char* filen=Tstr.toStdString().data();//ת����const char*�͵��ļ���
    videowr=cvCreateVideoWriter(filen,CV_FOURCC('M','J','P','G'),20,size,1);
    record=true;
}

void Widget::on_stoprecord_clicked()
{
    record=false;
    cvReleaseVideoWriter(&videowr);
}

void Widget::sendrequest()
{
    QByteArray block("GET /?action=stream\n\n");
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_0);
    client->write(block);
}

void Widget::socketerror()
{
    ui->statuslabel->setText(tr("socket error!"));
}

void Widget::read()
{    
    if(client->bytesAvailable()<3000)
        return;

    QByteArray tmpBlock;
    static const char SOIData[]={0xff,0xd8};
    static const char EOIData[]={0xff,0xd9};

    QByteArray SOIstr=QByteArray::fromRawData(SOIData,sizeof(SOIData));
    QByteArray EOIstr=QByteArray::fromRawData(EOIData,sizeof(EOIData));

    int SOIPos=0;
    int EOIPos=0;

    mutex.lock();
    tmpBlock=client->readAll();
    block1.append(tmpBlock);//����ʵ�ʶ���������

    if((SOIPos=block1.indexOf(SOIstr))!= -1)
    {
        if((EOIPos=block1.indexOf(EOIstr))!= -1)
        {
            EOIPos += 2;
            if(EOIPos>SOIPos)
            {
                QByteArray ba;
                ba=block1.mid(SOIPos,EOIPos-SOIPos);

                QImage image;
                image.loadFromData(ba);
                //***QImage --- IplImage*******/
                CvSize size;
                size.width=image.width();
                size.height=image.height();
                IplImage* img=cvCreateImage(size,IPL_DEPTH_8U, 3);//��cvReleaseImage���ʹ��
                QImageToIplImage(&image,img);
                //***put time on the IplImage***/
                QTime timer;
                timer=timer.currentTime();
                QString str=timer.toString();
                QByteArray ba1=str.toLatin1();
                const char* str2=ba1.data();
                Mat mat(img);
                putText(mat,str2,Point(0,30),3,1,Scalar(255,0,0),1,8,false);
                img=&mat.operator IplImage();
                //***IplImage --- QImage and display
                QImage* qImage=new QImage(qImageBuffer, img->width, img->height, QImage::Format_RGB32);
                IplImageToQImage(img,qImage,qImageBuffer);
                QPixmap pix;
                pix= pix.fromImage(*qImage);
                ui->Image->setPixmap(pix);
                delete qImage;
                //***record the IplImage***/
                if(record==true)
                    cvWriteFrame(videowr,img);//¼����Ƶ

                cvReleaseImage(&img);//��cvCreateImage���ʹ��
                ba.clear();
            }
            block1.remove(0,EOIPos+1);
        }
    }
    mutex.unlock();
}

void Widget::on_help_clicked()
{
    qDebug("help...\n");
}
